package Ejecutable;

import Controlador.Controlador;

public class Main {
    public static void main(String[] args) {
        new Controlador();
    }   
}
