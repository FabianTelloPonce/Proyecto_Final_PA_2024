package Vista.Interfaces;

public interface ActualizarTable {
    void actualizarTabla();
}
