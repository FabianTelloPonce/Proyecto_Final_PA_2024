package Vista.Empleados;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Controlador.Controlador;
import Vista.Interfaces.ActualizarTable;
import Vista.Plantillas.GenerarComponentes;
import Vista.Plantillas.GenerarVentanaFormulario;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class PantallaGestionEmpleados extends JPanel implements ActualizarTable {

    private JTextField campoBusqueda;
    private JTable tablaEmpleados;
    private JButton botonAgregar, botonEliminar, botonModificar;

    public PantallaGestionEmpleados() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Margen general
        setOpaque(true);

        // Panel de búsqueda
        JPanel panelBusqueda = GenerarComponentes.crearPanelFlowLayout(FlowLayout.CENTER, 10, 10);
        panelBusqueda.setBorder(GenerarComponentes.crearTitledBorder("Buscar Empleado"));

        JLabel etiquetaBusqueda = new JLabel("Nombre o ID:");
        etiquetaBusqueda.setFont(new Font("Arial", Font.BOLD, 14));
        etiquetaBusqueda.setForeground(new Color(255, 94, 98)); // Estilo opcional

        campoBusqueda = GenerarComponentes.crearCampoTexto(25);

        panelBusqueda.add(etiquetaBusqueda);
        panelBusqueda.add(campoBusqueda);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS));
        panelBotones.setOpaque(false);

        botonAgregar = GenerarComponentes.crearBoton("Agregar");
        botonEliminar = GenerarComponentes.crearBoton("Eliminar");
        botonModificar = GenerarComponentes.crearBoton("Modificar");

        panelBotones.add(botonAgregar);
        panelBotones.add(Box.createVerticalStrut(10)); // Espacio entre botones
        panelBotones.add(botonEliminar);
        panelBotones.add(Box.createVerticalStrut(10)); // Espacio entre botones
        panelBotones.add(botonModificar);

        // Añadir ActionListeners a los botones
        botonAgregar.addActionListener(e -> abrirFormularioAgregar());
        botonEliminar.addActionListener(e -> eliminarEmpleadoSeleccionado());
        botonModificar.addActionListener(e -> abrirFormularioModificar());

        // Tabla de empleados
        String[] columnas = {"ID", "Nombre", "Inicio de Contrato", "Fin de Contrato", "Rol"};
        tablaEmpleados = GenerarComponentes.crearTabla(columnas);
        JScrollPane scrollTabla = GenerarComponentes.crearScrollPane(tablaEmpleados);

        // Evento de búsqueda en tiempo real
        campoBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                String textoBusqueda = campoBusqueda.getText().trim();
                if (!textoBusqueda.isEmpty()) {
                    String condicion = "NOMBRE LIKE '%" + textoBusqueda + "%' OR ID_EMPLEADO LIKE '%" + textoBusqueda + "%'";
                    actualizarTablaConFiltro(condicion);
                } else {
                    actualizarTabla(); // Mostrar todos los datos si la búsqueda está vacía
                }
            }
        });

        // Añadir componentes al panel principal
        add(panelBusqueda, BorderLayout.NORTH);        // Barra de búsqueda en la parte superior
        add(panelBotones, BorderLayout.WEST);          // Botones de control en el lado izquierdo
        add(scrollTabla, BorderLayout.CENTER);         // Tabla de empleados en el centro
        actualizarTabla();
    }

    // Método para abrir el formulario de agregar empleado
    private void abrirFormularioAgregar() {
        JFrame formularioEmpleado = crearFormularioEmpleado("Agregar Empleado", null);
        formularioEmpleado.setVisible(true);
    }

    // Método para abrir el formulario de modificar empleado
    private void abrirFormularioModificar() {
        int selectedRow = tablaEmpleados.getSelectedRow();
        String idEmpleado = "";
        String nombre = "";
        String rol = "";
        String inicioContrato = "";
        String finContrato = "";
        if (selectedRow != -1) {
            idEmpleado = (String) tablaEmpleados.getValueAt(selectedRow, 0);
            nombre = (String) tablaEmpleados.getValueAt(selectedRow, 1);
            rol = (String) tablaEmpleados.getValueAt(selectedRow, 2);
            inicioContrato = (String) tablaEmpleados.getValueAt(selectedRow, 3);
            finContrato = (String) tablaEmpleados.getValueAt(selectedRow, 4);
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un empleado para modificar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
        JFrame formularioEmpleado = new JFrame("Modificar Empleado");
        formularioEmpleado.setSize(400, 350);
        formularioEmpleado.setLayout(new GridBagLayout());
        formularioEmpleado.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel etiquetaID = new JLabel("ID Empleado:");
        JTextField campoID = new JTextField(20);
        campoID.setText(idEmpleado);
        campoID.setEditable(false);

        JLabel etiquetaNombre = new JLabel("Nombre:");
        JTextField campoNombre = new JTextField(20);
        campoNombre.setText(nombre);
        campoNombre.setEditable(false);

        JLabel etiquetaRol = new JLabel("Rol:");
        String[] roles = {"Cajero", "Jefe de Inventario", "Gerente"};
        JComboBox<String> comboRol = new JComboBox<>(roles);
        comboRol.setSelectedItem(rol);

        JLabel etiquetaInicio = new JLabel("Inicio de Contrato:");
        JTextField campoInicio = new JTextField(20);
        campoInicio.setText(inicioContrato);
        campoInicio.setEditable(false);

        JLabel etiquetaFin = new JLabel("Fin de Contrato:");
        JTextField campoFin = new JTextField(20);
        campoFin.setText(finContrato);
        campoFin.setEditable(false);

        JButton botonGuardar = new JButton("Guardar");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(etiquetaID, gbc);
        gbc.gridx = 1;
        panelFormulario.add(campoID, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelFormulario.add(etiquetaNombre, gbc);
        gbc.gridx = 1;
        panelFormulario.add(campoNombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelFormulario.add(etiquetaRol, gbc);
        gbc.gridx = 1;
        panelFormulario.add(comboRol, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelFormulario.add(etiquetaInicio, gbc);
        gbc.gridx = 1;
        panelFormulario.add(campoInicio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelFormulario.add(etiquetaFin, gbc);
        gbc.gridx = 1;
        panelFormulario.add(campoFin, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        panelFormulario.add(botonGuardar, gbc);

        formularioEmpleado.add(panelFormulario);
        formularioEmpleado.setVisible(true);

        botonGuardar.addActionListener(e -> {
            String nuevoRol = (String) comboRol.getSelectedItem();
            String idEmpleadoMod = campoID.getText();
            Controlador.modificar("EMPLEADOS", "ID_EMPLEADO", idEmpleadoMod, "=", "ROL", nuevoRol);
            actualizarTabla();
            formularioEmpleado.dispose();
        });
    }

    // Método para eliminar el empleado seleccionado
    private void eliminarEmpleadoSeleccionado() {
        int selectedRow = tablaEmpleados.getSelectedRow();
        if (selectedRow != -1) {
            String idEmpleado = (String) tablaEmpleados.getValueAt(selectedRow, 0);
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar al empleado con ID " + idEmpleado + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                Controlador.eliminarDB("EMPLEADOS", "ID_EMPLEADO", idEmpleado);
                actualizarTabla();

            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un empleado para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

   // Método para crear el formulario de agregar/modificar empleado
private JFrame crearFormularioEmpleado(String titulo, String[] datosEmpleado) {
    JFrame ventana = GenerarVentanaFormulario.crearVentana(titulo, 400, 400); // Ajustar altura de la ventana

    JPanel panelFormulario = GenerarVentanaFormulario.crearPanelFormulario();

    // Crear componentes del formulario
    JLabel etiquetaID = GenerarVentanaFormulario.crearEtiqueta("ID Empleado:");
    JTextField campoID = GenerarVentanaFormulario.crearCampoTexto(20);
    campoID.setEditable(false); // ID no editable al modificar

    JLabel etiquetaNombre = GenerarVentanaFormulario.crearEtiqueta("Nombre:");
    JTextField campoNombre = GenerarVentanaFormulario.crearCampoTexto(20);

    JLabel etiquetaRol = GenerarVentanaFormulario.crearEtiqueta("Rol:");
    JTextField campoRol = GenerarVentanaFormulario.crearCampoTexto(20);

    JLabel etiquetaInicio = GenerarVentanaFormulario.crearEtiqueta("Inicio de Contrato:");
    JTextField campoInicio = GenerarVentanaFormulario.crearCampoTexto(20);

    JLabel etiquetaFin = GenerarVentanaFormulario.crearEtiqueta("Fin de Contrato:");
    JTextField campoFin = GenerarVentanaFormulario.crearCampoTexto(20);

    JLabel etiquetaPass = GenerarVentanaFormulario.crearEtiqueta("Contraseña:");
    JTextField campoPass = GenerarVentanaFormulario.crearCampoTexto(20);

    JButton botonGuardar = GenerarVentanaFormulario.crearBoton("Guardar");

    // Si es para modificar, llenar los campos con los datos existentes
    if (datosEmpleado != null) {
        campoID.setText(datosEmpleado[0]);
        campoNombre.setText(datosEmpleado[1]);
        campoRol.setText(datosEmpleado[2]);
        campoInicio.setText(datosEmpleado[3]);
        campoFin.setText(datosEmpleado[4]);
        campoPass.setText(datosEmpleado[5]); // Contraseña
    } else {
        campoID.setText(generarIDEmpleado()); // Generar un nuevo ID para agregar
    }

    // Añadir componentes al panel
    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaID, 0, 0, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoID, 1, 0, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaNombre, 0, 1, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoNombre, 1, 1, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaRol, 0, 2, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoRol, 1, 2, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaInicio, 0, 3, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoInicio, 1, 3, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaFin, 0, 4, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoFin, 1, 4, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, etiquetaPass, 0, 5, 1, 1);
    GenerarVentanaFormulario.agregarComponente(panelFormulario, campoPass, 1, 5, 2, 1);

    GenerarVentanaFormulario.agregarComponente(panelFormulario, botonGuardar, 1, 6, 1, 1);

    // Añadir el panel a la ventana
    ventana.add(panelFormulario);

    // Acción del botón Guardar
    botonGuardar.addActionListener(e -> {
        String idEmpleado = campoID.getText().trim();
        String nombre = campoNombre.getText().trim();
        String rol = campoRol.getText().trim();
        String inicioContrato = campoInicio.getText().trim();
        String finContrato = campoFin.getText().trim();
        String contraseña = campoPass.getText().trim();

        // Validar campos
        if (nombre.isEmpty() || rol.isEmpty() || inicioContrato.isEmpty() || finContrato.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(ventana, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si datosEmpleado es null, es agregar; de lo contrario, es modificar
        if (datosEmpleado == null) {
            // Agregar nuevo empleado
            String[] nuevoEmpleado = {idEmpleado, nombre, inicioContrato, finContrato, rol, contraseña};
            Controlador.agregarDB("EMPLEADO", null, nuevoEmpleado);
            actualizarTabla();
            ventana.dispose();
        } else {
            // Modificar empleado existente
            Controlador.modificar("EMPLEADO", "ID_EMPLEADO", idEmpleado, "=", "ROL", rol);
            actualizarTabla();
            ventana.dispose();
        }
    });

    return ventana;
}


    // Método para generar un nuevo ID de empleado (implementa tu lógica aquí)
    private String generarIDEmpleado() {
        // Por ejemplo, obtener el último ID y aumentar en 1
        ArrayList<String[]> empleados = Controlador.consultar("EMPLEADOS", null, null, null);
        int maxID = 0;
        for (String[] empleado : empleados) {
            try {
                int id = Integer.parseInt(empleado[0]);
                if (id > maxID) {
                    maxID = id;
                }
            } catch (NumberFormatException e) {
                // Ignorar IDs no numéricos
            }
        }
        return String.valueOf(maxID + 1);
    }

    // Método para actualizar la tabla con un filtro
    private void actualizarTablaConFiltro(String condicion) {
        String[] columnas = {"ID", "Nombre", "Inicio de Contrato", "Fin de Contrato", "Rol"};
        ArrayList<String[]> empleados = Controlador.consultar("EMPLEADOS", null, null, condicion);
        String[][] datos = new String[empleados.size()][columnas.length];
        for (int i = 0; i < empleados.size(); i++) {
            datos[i] = empleados.get(i);
        }
        tablaEmpleados.setModel(new DefaultTableModel(datos, columnas));

        // Ajustar anchos de columnas
        tablaEmpleados.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID
        tablaEmpleados.getColumnModel().getColumn(1).setPreferredWidth(200); // Nombre
        tablaEmpleados.getColumnModel().getColumn(2).setPreferredWidth(150); // Rol
        tablaEmpleados.getColumnModel().getColumn(3).setPreferredWidth(100); // Inicio de Contrato
        tablaEmpleados.getColumnModel().getColumn(4).setPreferredWidth(100); // Fin de Contrato

        // Opcional: Hacer que las columnas no sean redimensionables
        for (int i = 0; i < columnas.length; i++) {
            tablaEmpleados.getColumnModel().getColumn(i).setResizable(false);
        }
    }

    @Override
    public void actualizarTabla() {
        ArrayList<String[]> empleados = Controlador.consultar("EMPLEADOS", null, null, null);

        // Convertir los datos a un formato adecuado para la tabla
        Object[][] datosActualizados = new Object[empleados.size()][5];
        int i = 0;
        for (String[] empleado : empleados) {
            // ID, Nombre, Rol, Fecha de Inicio, Fecha de Fin
            datosActualizados[i][0] = empleado[0];  // ID_EMPLEADO
            datosActualizados[i][1] = empleado[1];  // NOMBRE
            datosActualizados[i][2] = empleado[2];  // ROL
            datosActualizados[i][3] = empleado[3];  // INICIO_CONTRATO
            datosActualizados[i][4] = empleado[4];  // FINAL_CONTRATO
            i++;
        }

        // Actualizar el modelo de la tabla con los nuevos datos
        tablaEmpleados.setModel(new DefaultTableModel(
            datosActualizados,
            new String[] {"ID", "Nombre", "Inicio de Contrato", "Fin de Contrato", "Rol"}
        ));

        // Ajustar el ancho de las columnas
        tablaEmpleados.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID
        tablaEmpleados.getColumnModel().getColumn(1).setPreferredWidth(200); // Nombre
        tablaEmpleados.getColumnModel().getColumn(2).setPreferredWidth(150); // Rol
        tablaEmpleados.getColumnModel().getColumn(3).setPreferredWidth(100); // Inicio de Contrato
        tablaEmpleados.getColumnModel().getColumn(4).setPreferredWidth(100); // Fin de Contrato

        // Opcional: Hacer que las columnas no sean redimensionables
        for (int j = 0; j < tablaEmpleados.getColumnCount(); j++) {
            tablaEmpleados.getColumnModel().getColumn(j).setResizable(false);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        Color colorInicio = new Color(255, 94, 98);
        Color colorFinal = new Color(255, 175, 123);
        int width = getWidth();
        int height = getHeight();
        GradientPaint gp = new GradientPaint(0, 0, colorInicio, 0, height, colorFinal);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
    }
}
